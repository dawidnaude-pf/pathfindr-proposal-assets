#!/usr/bin/env python3
import json
import subprocess
import tempfile
import unittest
from pathlib import Path


SKILL_DIR = Path(__file__).resolve().parents[1]
SCRIPT = SKILL_DIR / "scripts" / "generate_proposal.py"
EXAMPLE = SKILL_DIR / "examples" / "brief.example.json"
MANIFEST = SKILL_DIR / "assets" / "logo-manifest.json"
CONTENT_LIBRARY = SKILL_DIR / "assets" / "content-library.json"


class ProposalGeneratorTest(unittest.TestCase):
    def generate_example(self) -> str:
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "proposal.html"
            result = subprocess.run(
                ["python3", str(SCRIPT), "--brief", str(EXAMPLE), "--output", str(output)],
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            return output.read_text(encoding="utf-8")

    def test_generates_current_capability_accelerator_structure(self):
        html = self.generate_example()

        required_copy = [
            "Client Organisation",
            "AI Capability Accelerator",
            "What we heard",
            "Current state",
            "Future vision",
            "Obstacles",
            "Quick wins",
            "Right fit, wrong fit",
            "Our process",
            "The questions this program answers",
            "How do we get impact as soon as possible?",
            "Get ready",
            "Fast start",
            "Keep momentum",
            "Board 01 · AI Theory and Strategic Awareness",
            "Board 02 · Practical AI Follow-Along",
            "Senior Leaders 01 · AI Foundations",
            "Senior Leaders 02 · Executive AI Mastery",
            "Senior Leaders 03 · Reimagine Session",
            "General Managers · AI Capability Awareness",
            "2 hours virtual · up to 50",
            "Practice between sessions",
            "GM logistics",
            "Tool and licence assumptions",
            "Six AI opportunity buckets",
            "Native tools first",
            "Scope boundaries",
            "About Pathfindr",
        ]
        for text in required_copy:
            self.assertIn(text, html)

        self.assertNotIn("Afford", html)
        self.assertNotIn("Nick Johnson", html)
        self.assertNotIn("__PROSPECT_NAME__", html)
        self.assertNotIn("__LOGO_GRID__", html)
        self.assertNotIn("data:image", html)
        self.assertNotIn("raw.githubusercontent.com/dawidnaude-pf/pathfindr-proposal-assets", html)
        self.assertNotIn("placehold.co", html)

    def test_uses_public_hosted_pathfindr_assets_and_logo_wall(self):
        html = self.generate_example()

        self.assertIn("team/dawid-naude.webp", html)
        self.assertIn("team/caroline-dickie.webp", html)
        self.assertIn("about/pathfindr-team-melbourne.webp", html)
        self.assertIn("about/laura-hatton-facilitating.webp", html)
        self.assertIn("about/dawid-naude-speaking.webp", html)
        self.assertIn("about/lindsay-page-facilitating.webp", html)

        expected_brands = [
            "Accenture",
            "Johnson &amp; Johnson",
            "Coles Group",
            "Virgin Australia",
            "ABC",
            "AFL",
            "RACQ",
            "Engineers Australia",
            "Australian Catholic University",
            "Cotton On Group",
            "CHU",
            "Australian Venue Co",
        ]
        for brand in expected_brands:
            self.assertIn(brand, html)

        manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
        base_url = manifest["hosting"]["base_url"]
        self.assertEqual(manifest["hosting"]["mode"], "owned-public-github-jsdelivr")
        self.assertTrue(base_url.startswith("https://cdn.jsdelivr.net/gh/"), base_url)
        for logo in manifest["logos"]:
            self.assertTrue(logo["url"].startswith("https://"), logo)
            self.assertTrue(logo["url"].startswith(f"{base_url}/"), logo)
            self.assertIn("source_url", logo)
            self.assertNotIn("file://", logo["url"])
            self.assertNotIn("127.0.0.1", logo["url"])

        library = json.loads(CONTENT_LIBRARY.read_text(encoding="utf-8"))
        asset_base = library["asset_hosting"]["base_url"]
        self.assertTrue(asset_base.startswith("https://cdn.jsdelivr.net/gh/"))
        for person in library["people"]:
            self.assertTrue(person["image_url"].startswith(f"{asset_base}/"), person)
        for item in library["pathfindr"]["assets"]["delivery_images"]:
            self.assertTrue(item["url"].startswith(f"{asset_base}/about/"), item)

    def test_can_select_people_and_case_studies_from_content_library(self):
        brief = json.loads(EXAMPLE.read_text(encoding="utf-8"))
        brief.pop("facilitators", None)
        brief["facilitator_ids"] = ["ai-strategy-lead"]
        brief["case_study_ids"] = ["board-ai-roadmap"]

        content_library = {
            "version": "2026-06-29",
            "people": [
                {
                    "id": "ai-strategy-lead",
                    "name": "Reusable Team Member",
                    "role": "AI Strategy Lead",
                    "bio": "Reusable biography copy from the content library.",
                    "image_url": "https://example.com/team/reusable-team-member.jpg",
                    "tags": ["strategy", "leadership"],
                }
            ],
            "pathfindr": {},
            "case_studies": [
                {
                    "id": "board-ai-roadmap",
                    "title": "Board AI Roadmap",
                    "client": "Generic Enterprise",
                    "sector": "Professional Services",
                    "summary": "Reusable case study summary from the content library.",
                    "outcomes": ["Prioritised roadmap", "Governance model"],
                    "image_url": "https://example.com/cases/board-ai-roadmap.jpg",
                    "tags": ["board", "roadmap"],
                }
            ],
        }

        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            brief_path = tmp_path / "brief.json"
            library_path = tmp_path / "content-library.json"
            output = tmp_path / "proposal.html"
            brief_path.write_text(json.dumps(brief), encoding="utf-8")
            library_path.write_text(json.dumps(content_library), encoding="utf-8")

            result = subprocess.run(
                [
                    "python3",
                    str(SCRIPT),
                    "--brief",
                    str(brief_path),
                    "--content-library",
                    str(library_path),
                    "--output",
                    str(output),
                ],
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            html = output.read_text(encoding="utf-8")

        self.assertIn("Reusable Team Member", html)
        self.assertIn("Reusable biography copy from the content library.", html)
        self.assertIn("https://example.com/team/reusable-team-member.jpg", html)
        self.assertIn("Board AI Roadmap", html)
        self.assertIn("Reusable case study summary from the content library.", html)
        self.assertIn("Prioritised roadmap", html)


if __name__ == "__main__":
    unittest.main()
