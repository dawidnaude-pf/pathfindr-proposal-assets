---
name: proposal-page-generator
description: Use when a user wants a polished B2B proposal HTML page, proposal microsite, sales walkthrough page, leadership accelerator proposal, or reusable Pathfindr-style commercial proposal.
---

# Proposal Page Generator

## Overview

Generate a concise, client-ready Pathfindr proposal microsite from a structured brief. Keep prospect-specific facts in the brief, keep design in the template, and keep reusable Pathfindr proof/assets in the content library and logo manifest.

## Outcome First

If the buyer outcome is not clear, ask one question before writing:

> What decision should this proposal help the buyer make?

Proceed without asking when the user has already supplied the meeting, buyer, scope, or proposal objective.

## Workflow

1. Gather source truth: meeting notes, prior proposal, CRM/email context, pricing, scope, buyer concerns, and any required prospect logo.
2. Check `assets/content-library.json` for reusable people, headshots, bios, hosted About Pathfindr imagery, case studies, and proof points. Add or update records there before copying content into a one-off brief.
3. Create a brief JSON under the current project, starting from `examples/brief.example.json`. Do not leave named sample companies in the brief.
4. Select reusable content in the brief with stable IDs:
   ```json
   {
     "facilitator_ids": ["dawid-naude"],
     "case_study_ids": ["executive-ai-roadmap"]
   }
   ```
   Use inline `facilitators` or `case_studies` only for genuinely one-off content.
5. Generate HTML:
   ```bash
   SKILL_DIR="${CODEX_HOME:-$HOME/.codex}/skills/proposal-page-generator"
   python3 "$SKILL_DIR/scripts/generate_proposal.py" \
     --brief /absolute/path/to/brief.json \
     --output /absolute/path/to/outputs/proposal.html
   ```
6. Verify:
   ```bash
   python3 "$SKILL_DIR/tests/test_generate_proposal.py"
   python3 "$SKILL_DIR/scripts/verify_public_assets.py"
   ```
7. Open the output in a browser. Check desktop and narrow mobile widths for broken logos, overflowing text, and weak proposal flow.

## Brief Rules

- Use placeholders only in examples: `Client Organisation`, `Decision Maker`, `Month YYYY`.
- In real proposals, replace placeholders with actual buyer details from source truth.
- Do not copy prior prospect names into reusable examples or templates.
- Keep each section direct: what we heard, summary, right fit/wrong fit, process, leader questions, program delivery, tool assumptions, opportunity buckets, native-tools-first, investment, scope boundaries, experience, facilitators, About Pathfindr, next step.
- Put uncomfortable facts in plain language. Avoid vague transformation copy.
- For leadership accelerator proposals, use the three-phase delivery scaffold:
  - `Get ready`: signature/deposit, briefing, roles, licences, survey, GM logistics, microsite setup.
  - `Fast start`: Board, Senior Leader, and GM sessions. Make the sessions the hero.
  - `Keep momentum`: office hours, microsite delivery, recordings, outcomes call, Unprompted, social tile.
- The `heard` panel should use four cards: `Current state`, `Future vision`, `Obstacles`, `Quick wins`. Quick wins should be concrete examples, not generic benefits.
- Include the highlighted eleventh leader question: `How do we get impact as soon as possible?`
- Keep the GM session as one 2-hour virtual awareness session, plus one 1-hour GM logistics call in Get Ready.

## Content Library

Use `assets/content-library.json` as the lightweight database for reusable proof material:
- `people`: team members, roles, bios, public `image_url` or `headshot_url`, tags.
- `pathfindr`: fixed About Pathfindr copy, hosted team/delivery photos, client names, partners, capabilities, recognition.
- `case_studies`: title, client label, sector, summary, outcomes, public `image_url`, tags.

Rules:
- Keep `id` values stable and human-readable. Changing an id breaks existing briefs.
- Use public HTTPS image URLs so published microsites do not need local image files.
- Reusable fixed assets are hosted from the public GitHub repo `dawidnaude-pf/pathfindr-proposal-assets` through jsDelivr URLs.
- Prefer generic client labels such as `Representative enterprise` unless a named case study is approved for use.
- Briefs should reference `facilitator_ids` and `case_study_ids`; avoid pasting bios and case studies into every proposal.
- If real case images are not available, leave `image_url` blank. Do not use placeholder image services in generated proposals.
- Do not embed base64 images in generated proposals.

## Logo Handling

Shared credibility logos live in `assets/logo-manifest.json`, ordered by `priority`.

Rules:
- Do not hard-code logos in generated HTML outside the manifest.
- Use public HTTPS URLs only.
- Use `class` values `square`, `wide`, or `tall` to balance visual size.
- Put the most recognisable brands first.
- Prospect logos are brief-specific via `prospect_logo_url`; they are not part of the default sample.

The default manifest uses mirrored logo files hosted in the public GitHub repo `dawidnaude-pf/pathfindr-proposal-assets`, served through jsDelivr CDN URLs. Generated microsites can therefore render logos without bundling local image files.

To refresh the hosted logo pack or move it to a different public blob/CDN host:

```bash
python3 "$SKILL_DIR/scripts/mirror_logo_assets.py" \
  --output-dir /absolute/path/to/logo-assets \
  --public-base-url https://your-public-cdn.example.com/proposal-logos \
  --output-manifest /absolute/path/to/logo-manifest.public.json
```

Then upload the downloaded files to that public base URL, commit or publish the generated manifest, and generate with `--logo-manifest /absolute/path/to/logo-manifest.public.json`.

If no writable public blob store or CDN credentials are available, state that clearly and keep the default jsDelivr manifest rather than inventing a fake hosted location.

## Quality Bar

Before handoff:
- No prior prospect names in generic files.
- No unreplaced template tokens.
- Logos load from public HTTPS URLs.
- Reusable headshots and About Pathfindr photos load from public HTTPS URLs.
- Selected team members and case studies resolve from `assets/content-library.json`.
- Experience logo wall looks balanced on desktop and mobile.
- The first screen is the proposal, not a landing page.
- The proposal has an explicit decision requested.
- The next step is operationally clear.
- No `data:image`, `placehold.co`, local file paths, localhost URLs, or stale prior prospect names in generated HTML.

## Common Mistakes

- Reusing a previous proposal with stale company names.
- Hard-coding logos directly in HTML instead of editing the manifest.
- Treating a pretty page as sufficient when the decision path is unclear.
- Adding broad AI hype instead of buyer-specific current state and decision material.
- Pointing generated pages at scattered third-party logo URLs when the maintained hosted manifest is available.
