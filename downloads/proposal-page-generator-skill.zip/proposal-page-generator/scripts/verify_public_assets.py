#!/usr/bin/env python3
import argparse
import json
import urllib.request
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple


SKILL_DIR = Path(__file__).resolve().parents[1]
DEFAULT_MANIFEST = SKILL_DIR / "assets" / "logo-manifest.json"
DEFAULT_CONTENT_LIBRARY = SKILL_DIR / "assets" / "content-library.json"


def read_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def collect_content_urls(node: Any, path: str = "") -> Iterable[Tuple[str, str]]:
    if isinstance(node, dict):
        for key, value in node.items():
            next_path = f"{path}.{key}" if path else key
            if isinstance(value, str) and value.startswith("https://") and (
                key in {"image_url", "headshot_url", "thumbnail_url", "url", "image"}
            ):
                yield next_path, value
            else:
                yield from collect_content_urls(value, next_path)
    elif isinstance(node, list):
        for index, item in enumerate(node):
            yield from collect_content_urls(item, f"{path}[{index}]")


def verify_url(label: str, url: str, timeout: int) -> Optional[str]:
    if not url.startswith("https://"):
        return f"{label}: not HTTPS: {url}"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "proposal-page-generator/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as response:
            status = response.status
            content_type = response.headers.get("content-type", "")
    except Exception as exc:
        return f"{label}: {exc}"
    if status >= 400:
        return f"{label}: HTTP {status}, content-type {content_type}"
    if "image/" not in content_type:
        return f"{label}: expected image content-type, got {content_type}"
    print(f"OK {label} {status} {content_type}")
    return None


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify proposal public logo and reusable image URLs.")
    parser.add_argument("--logo-manifest", default=DEFAULT_MANIFEST, type=Path)
    parser.add_argument("--content-library", default=DEFAULT_CONTENT_LIBRARY, type=Path)
    parser.add_argument("--timeout", default=20, type=int)
    args = parser.parse_args()

    failures: List[str] = []
    manifest = read_json(args.logo_manifest)
    for logo in manifest.get("logos", []):
        failure = verify_url(f"logo:{logo['name']}", logo["url"], args.timeout)
        if failure:
            failures.append(failure)

    library = read_json(args.content_library)
    for label, url in collect_content_urls(library):
        if url:
            failure = verify_url(f"content:{label}", url, args.timeout)
            if failure:
                failures.append(failure)

    if failures:
        print("\nFAILURES")
        for failure in failures:
            print(f"- {failure}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
