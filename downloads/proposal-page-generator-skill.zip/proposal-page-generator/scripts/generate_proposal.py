#!/usr/bin/env python3
import argparse
import html
import json
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List


SKILL_DIR = Path(__file__).resolve().parents[1]
DEFAULT_TEMPLATE = SKILL_DIR / "templates" / "proposal-template.html"
DEFAULT_MANIFEST = SKILL_DIR / "assets" / "logo-manifest.json"
DEFAULT_CONTENT_LIBRARY = SKILL_DIR / "assets" / "content-library.json"


def esc(value: Any) -> str:
    return html.escape(str(value or ""), quote=True)


def rich(value: Any) -> str:
    return esc(value).replace("\n", "<br>")


def read_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def index_by_id(items: Iterable[Dict[str, Any]], label: str) -> Dict[str, Dict[str, Any]]:
    indexed: Dict[str, Dict[str, Any]] = {}
    for item in items:
        item_id = item.get("id")
        if not item_id:
            raise ValueError(f"{label} entry is missing an id")
        if item_id in indexed:
            raise ValueError(f"Duplicate {label} id: {item_id}")
        indexed[item_id] = item
    return indexed


def records_by_ids(
    selected_ids: Iterable[str],
    library_items: Iterable[Dict[str, Any]],
    label: str,
) -> List[Dict[str, Any]]:
    indexed = index_by_id(library_items, label)
    records = []
    missing = []
    for selected_id in selected_ids:
        record = indexed.get(selected_id)
        if record:
            records.append(record)
        else:
            missing.append(selected_id)
    if missing:
        raise ValueError(f"Unknown {label} id(s): {', '.join(missing)}")
    return records


def selected_people(brief: Dict[str, Any], content_library: Dict[str, Any]) -> List[Dict[str, Any]]:
    selected = []
    if brief.get("facilitator_ids"):
        selected.extend(records_by_ids(brief["facilitator_ids"], content_library.get("people", []), "people"))
    selected.extend(brief.get("facilitators", []))
    return selected


def selected_case_studies(brief: Dict[str, Any], content_library: Dict[str, Any]) -> List[Dict[str, Any]]:
    selected = []
    if brief.get("case_study_ids"):
        selected.extend(
            records_by_ids(brief["case_study_ids"], content_library.get("case_studies", []), "case_studies")
        )
    selected.extend(brief.get("case_studies", []))
    return selected


def list_items(items: Iterable[Any]) -> str:
    return "\n".join(f"<li>{rich(item)}</li>" for item in items)


def paragraph_items(items: Iterable[Any]) -> str:
    return "\n".join(f"<p>{rich(item)}</p>" for item in items if str(item or "").strip())


def cover_title(title: str) -> str:
    clean = esc(title)
    if "Accelerator" in clean:
        clean = clean.replace("Accelerator", "<em>Accelerator</em>", 1)
    return clean


def cover_facts(items: List[Dict[str, str]]) -> str:
    cards = []
    for item in items:
        icon = esc(item.get("icon", "circle"))
        cards.append(
            '<div class="cover-fact">'
            f'<div class="cover-fact-key"><i data-lucide="{icon}"></i>{esc(item.get("label", ""))}</div>'
            f'<div class="cover-fact-val">{rich(item.get("value", ""))}</div>'
            '</div>'
        )
    return "\n".join(cards)


def heard_cards(items: List[Dict[str, Any]]) -> str:
    cards = []
    for item in items:
        icon = esc(item.get("icon", "circle"))
        cards.append(
            '<article class="heard-card">'
            f'<div class="heard-card-top"><i data-lucide="{icon}"></i><h3>{esc(item.get("title", ""))}</h3></div>'
            f'<ul class="heard-list">{list_items(item.get("items", []))}</ul>'
            '</article>'
        )
    return "\n".join(cards)


def summary_cards(items: List[Dict[str, str]]) -> str:
    cards = []
    for index, item in enumerate(items, 1):
        cards.append(
            '<div class="summary-card">'
            f'<div class="summary-num">{index:02d}</div>'
            f'<h3>{esc(item.get("title", ""))}</h3>'
            f'<p>{rich(item.get("body", ""))}</p>'
            '</div>'
        )
    return "\n".join(cards)


def question_cards(items: List[Dict[str, Any]]) -> str:
    cards = []
    for index, item in enumerate(items, 1):
        classes = "question-card"
        if item.get("highlight"):
            classes += " is-impact"
        title = item.get("title") or item.get("question", "")
        cards.append(
            f'<div class="{classes}">'
            f'<h3>{index}. {esc(title)}</h3>'
            f'<p>{rich(item.get("body", ""))}</p>'
            '</div>'
        )
    return "\n".join(cards)


def phase_sessions(sessions: List[Dict[str, Any]]) -> str:
    blocks = []
    for item in sessions:
        impact = ""
        if item.get("impact"):
            impact = f'<div class="phase-session-impact"><strong>Immediate impact:</strong> {rich(item["impact"])}</div>'
        blocks.append(
            '<div class="phase-session">'
            '<div class="phase-session-top">'
            f'<div class="phase-session-name">{esc(item.get("name", ""))}</div>'
            f'<div class="phase-session-meta">{esc(item.get("meta", ""))}</div>'
            '</div>'
            f'<p>{rich(item.get("purpose", ""))}</p>'
            f'<ul class="phase-session-points">{list_items(item.get("points", []))}</ul>'
            f'{impact}'
            '</div>'
        )
    return "\n".join(blocks)


def phase_panel(items: List[Dict[str, Any]]) -> str:
    cards = []
    for item in items:
        classes = f'phase-card {esc(item.get("class", ""))}'.strip()
        components = ""
        if item.get("components"):
            components = '<div class="phase-components">' + "".join(
                f"<span>{esc(component)}</span>" for component in item.get("components", [])
            ) + "</div>"
        item_list = ""
        if item.get("items"):
            item_list = f'<ul class="phase-list">{list_items(item.get("items", []))}</ul>'
        sessions = ""
        if item.get("sessions"):
            sessions = f'<div class="phase-session-list">{phase_sessions(item.get("sessions", []))}</div>'
        homework = ""
        if item.get("homework"):
            homework = (
                '<div class="phase-homework">'
                f'<strong>{esc(item["homework"].get("title", "Practice between sessions"))}</strong>'
                f'<p>{rich(item["homework"].get("body", ""))}</p>'
                '</div>'
            )
        cards.append(
            f'<div class="{classes}">'
            f'<div class="phase-kicker">{esc(item.get("kicker", ""))}</div>'
            f'<h3>{esc(item.get("title", ""))}</h3>'
            f'<p>{rich(item.get("body", ""))}</p>'
            f'{components}{item_list}{sessions}{homework}'
            '</div>'
        )
    return "\n".join(cards)


def phase_footnotes(items: List[Dict[str, str]]) -> str:
    if not items:
        return ""
    return '<div class="phase-footnotes">' + "\n".join(
        '<div class="phase-footnote">'
        f'<strong>{esc(item.get("title", ""))}</strong>'
        f'<span>{rich(item.get("body", ""))}</span>'
        '</div>'
        for item in items
    ) + "</div>"


def fit_blocks(items: List[Dict[str, str]]) -> str:
    return "\n".join(
        '<div class="fit-block">'
        f'<div class="fit-label">{esc(item.get("label", ""))}</div>'
        f'<div class="fit-body">{rich(item.get("body", ""))}</div>'
        '</div>'
        for item in items
    )


def bucket_cards(items: List[Dict[str, str]], example_label: str) -> str:
    cards = []
    for item in items:
        example = ""
        if item.get("example"):
            example = f'<div class="bucket-example"><strong>{esc(example_label)}:</strong> {rich(item["example"])}</div>'
        cards.append(
            '<div class="bucket-card">'
            f'<div class="bucket-title">{esc(item.get("title", ""))}</div>'
            f'<div class="bucket-body">{rich(item.get("body", ""))}</div>'
            f'{example}'
            '</div>'
        )
    return "\n".join(cards)


def native_tools(items: List[str]) -> str:
    return "".join(f"<span>{esc(item)}</span>" for item in items)


def cta_steps(items: List[Dict[str, str]]) -> str:
    cards = []
    for index, item in enumerate(items, 1):
        cards.append(
            "<div>"
            f'<div class="cta-step-num">{index:02d}</div>'
            f'<div class="cta-step-title">{esc(item.get("title", ""))}</div>'
            f'<div class="cta-step-body">{rich(item.get("body", ""))}</div>'
            "</div>"
        )
    return "\n".join(cards)


def fit_compare(right_items: List[str], wrong_items: List[str]) -> str:
    if not right_items and not wrong_items:
        return ""
    return (
        '<section class="doc">'
        '<div class="doc-inner">'
        '<div class="section-head"><span class="section-label"><i data-lucide="badge-check"></i>Right fit, wrong fit</span></div>'
        '<div class="section-rule"></div>'
        '<div class="fit-compare">'
        '<div class="fit-card is-right"><div class="fit-card-kicker">Right fit</div><ul class="fit-list">'
        f'{list_items(right_items)}'
        '</ul></div>'
        '<div class="fit-card"><div class="fit-card-kicker">Wrong fit</div><ul class="fit-list">'
        f'{list_items(wrong_items)}'
        '</ul></div>'
        '</div></div></section>'
    )


def process_section(items: List[Dict[str, str]]) -> str:
    if not items:
        return ""
    return (
        '<section class="doc">'
        '<div class="doc-inner">'
        '<div class="section-head"><span class="section-label"><i data-lucide="workflow"></i>Our process</span></div>'
        '<div class="section-rule"></div>'
        '<div class="summary-grid">'
        + summary_cards(items)
        + '</div></div></section>'
    )


def facilitator_cards(items: List[Dict[str, str]]) -> str:
    cards = []
    for item in items:
        image_url = item.get("image_url") or item.get("headshot_url")
        image_html = ""
        if image_url:
            image_html = (
                '<img class="facil-avatar" '
                f'src="{esc(image_url)}" alt="{esc(item.get("name", "Team member"))}" '
                'loading="lazy" decoding="async">'
            )
        cards.append(
            '<article class="facil-card">'
            f'{image_html}'
            '<div>'
            f'<h3>{esc(item.get("name", ""))}</h3>'
            f'<div class="facil-role">{esc(item.get("role", ""))}</div>'
            f'<p>{rich(item.get("bio", ""))}</p>'
            '</div>'
            '</article>'
        )
    return "\n".join(cards)


def case_study_section(items: List[Dict[str, Any]]) -> str:
    if not items:
        return ""
    cards = []
    for item in items:
        image_html = ""
        image_url = item.get("image_url") or item.get("thumbnail_url")
        if image_url:
            image_html = (
                f'<img class="case-image" src="{esc(image_url)}" '
                f'alt="{esc(item.get("title", "Case study"))} image" loading="lazy" decoding="async">'
            )
        meta = esc(item.get("client", ""))
        if item.get("sector"):
            meta += f" &middot; {esc(item.get('sector', ''))}"
        cards.append(
            '<article class="case-card">'
            f'{image_html}'
            f'<div class="case-meta">{meta}</div>'
            f'<h3 class="case-title">{esc(item.get("title", ""))}</h3>'
            f'<p class="case-body">{rich(item.get("summary", ""))}</p>'
            f'<ul class="case-outcomes">{list_items(item.get("outcomes", []))}</ul>'
            '</article>'
        )
    return (
        '<section class="doc">'
        '<div class="doc-inner">'
        '<div class="section-head"><span class="section-label"><i data-lucide="file-check-2"></i>Case studies</span></div>'
        '<div class="section-rule"></div>'
        '<div class="case-grid">'
        + "\n".join(cards)
        + '</div></div></section>'
    )


def logo_grid(manifest: Dict[str, Any], brief: Dict[str, Any]) -> str:
    cells: List[str] = []
    prospect_logo_url = brief.get("prospect_logo_url", "")
    if prospect_logo_url:
        prospect_name = esc(brief.get("prospect_name", "Prospect"))
        cells.append(
            '<div class="logo-cell logo-brand is-prospect">'
            f'<img class="brand-logo brand-logo-wide" src="{esc(prospect_logo_url)}" alt="{prospect_name} logo" loading="eager" decoding="async">'
            f'<div class="brand-name">{prospect_name}</div>'
            '<div class="brand-note">Prepared for</div>'
            '</div>'
        )

    logos = sorted(manifest.get("logos", []), key=lambda item: item.get("priority", 999))
    for logo in logos:
        logo_class = logo.get("class", "square")
        image_class = "brand-logo"
        if logo_class == "wide":
            image_class += " brand-logo-wide"
        elif logo_class == "tall":
            image_class += " brand-logo-tall"
        name = esc(logo["name"])
        url = esc(logo["url"])
        cells.append(
            '<div class="logo-cell logo-brand">'
            f'<img class="{image_class}" src="{url}" alt="{name} logo" loading="eager" decoding="async">'
            f'<div class="brand-name">{name}</div>'
            '</div>'
        )
    return "\n".join(cells)


def about_pathfindr_section(pathfindr: Dict[str, Any]) -> str:
    if not pathfindr:
        return ""
    assets = pathfindr.get("assets", {})
    team_image = assets.get("team_photo", {})
    delivery_images = assets.get("delivery_images", [])
    team_image_html = ""
    if team_image.get("url"):
        team_image_html = (
            f'<img class="ap-team-photo" src="{esc(team_image["url"])}" '
            f'alt="{esc(team_image.get("alt", "Pathfindr team"))}" loading="lazy" decoding="async">'
            f'<div class="ap-caption">{esc(team_image.get("caption", ""))}</div>'
        )
    delivery_html = ""
    if delivery_images:
        delivery_html = (
            '<div class="ap-action-grid">'
            + "\n".join(
                f'<img class="ap-action-img" src="{esc(item.get("url", ""))}" alt="{esc(item.get("alt", ""))}" loading="lazy" decoding="async">'
                for item in delivery_images
            )
            + '</div>'
            f'<div class="ap-caption">{esc(assets.get("delivery_caption", ""))}</div>'
        )

    columns = []
    for column in pathfindr.get("columns", []):
        cap_class = " ap-cap" if column.get("capability_style") else ""
        columns.append(
            '<div class="ap-col">'
            f'<div class="ap-col-label">{esc(column.get("title", ""))}</div>'
            f'<div class="ap-col-list{cap_class}">'
            + "\n".join(f"<span>{rich(item)}</span>" for item in column.get("items", []))
            + '</div></div>'
        )

    recognition = ""
    if pathfindr.get("recognition"):
        recognition = (
            '<div class="ap-col">'
            '<div class="ap-col-label">Recognition</div>'
            '<div class="ap-col-list">'
            + "\n".join(f"<span>{esc(item)}</span>" for item in pathfindr.get("recognition", []))
            + '</div></div>'
        )

    return (
        '<section class="doc tight about-pathfindr">'
        '<div class="doc-inner">'
        '<div class="section-head"><span class="section-label"><i data-lucide="sparkles"></i>About Pathfindr</span></div>'
        '<div class="section-rule"></div>'
        f'<h2 class="doc-headline">{esc(pathfindr.get("headline", ""))}</h2>'
        f'<div class="ap-intro">{paragraph_items(pathfindr.get("body", []))}</div>'
        '<div class="ap-visuals">'
        f'<div>{team_image_html}</div>'
        f'<div>{delivery_html}</div>'
        '</div>'
        '<div class="ap-band">'
        + "\n".join(columns)
        + recognition
        + '</div></div></section>'
    )


def contact_block(contact: Dict[str, str]) -> str:
    lines = [contact.get("primary"), contact.get("website")]
    clean = [esc(item) for item in lines if item]
    return "<br>" + "<br>".join(clean) if clean else ""


def render(brief: Dict[str, Any], manifest: Dict[str, Any], content_library: Dict[str, Any], template: str) -> str:
    people = selected_people(brief, content_library)
    case_studies = selected_case_studies(brief, content_library)
    pathfindr = content_library.get("pathfindr", {})
    opportunity = brief.get("opportunity_buckets", {})
    investment = brief.get("investment", {})
    scope = brief.get("scope", {})
    proposal_title = brief["proposal_title"]
    prepared_by = brief.get("prepared_by", "Pathfindr")
    prospect_name = brief.get("prospect_name", "Client Organisation")

    replacements = {
        "__TITLE__": esc(f"{proposal_title} · {prepared_by}"),
        "__PREPARED_BY__": esc(prepared_by),
        "__PROPOSAL_TITLE__": esc(proposal_title),
        "__PROSPECT_NAME__": esc(prospect_name),
        "__CONTACT_NAME__": esc(brief.get("contact_name", "Decision Maker")),
        "__DATE_LABEL__": esc(brief.get("date_label", "Month YYYY")),
        "__CONFIDENTIALITY__": esc(brief.get("confidentiality", "Confidential")),
        "__COVER_TITLE__": cover_title(proposal_title),
        "__SUBTITLE__": rich(brief.get("subtitle", "")),
        "__COVER_FACTS__": cover_facts(brief.get("cover_facts", [])),
        "__RECOMMENDED_NEXT_STEP__": rich(brief.get("recommended_next_step", brief.get("decision_requested", ""))),
        "__HEARD_HEADLINE__": esc(brief.get("heard_headline", "")),
        "__HEARD_CARDS__": heard_cards(brief.get("heard", [])),
        "__SUMMARY_HEADLINE__": esc(brief.get("summary_headline", "")),
        "__SUMMARY_BODY__": paragraph_items(brief.get("summary_body", [])),
        "__SUMMARY_CARDS__": summary_cards(brief.get("summary_cards", [])),
        "__RIGHT_FIT_SECTION__": fit_compare(brief.get("right_fit", []), brief.get("wrong_fit", [])),
        "__PROCESS_SECTION__": process_section(brief.get("process", [])),
        "__QUESTION_INTRO__": rich(brief.get("question_intro", "")),
        "__QUESTION_CARDS__": question_cards(brief.get("questions", [])),
        "__PHASE_HEADLINE__": esc(brief.get("delivery", {}).get("headline", "")),
        "__PHASE_BODY__": paragraph_items(brief.get("delivery", {}).get("body", [])),
        "__PHASE_PANEL__": phase_panel(brief.get("delivery", {}).get("phases", [])),
        "__PHASE_FOOTNOTES__": phase_footnotes(brief.get("delivery", {}).get("footnotes", [])),
        "__TOOL_REQUIREMENT_BLOCKS__": fit_blocks(brief.get("tool_requirements", [])),
        "__BUCKETS_HEADLINE__": esc(opportunity.get("headline", "")),
        "__BUCKETS_BODY__": paragraph_items(opportunity.get("body", [])),
        "__BUCKET_CARDS__": bucket_cards(
            opportunity.get("buckets", []),
            opportunity.get("example_label", f"{prospect_name} example"),
        ),
        "__NATIVE_TOOLS__": native_tools(brief.get("native_tools", [])),
        "__INVESTMENT_HTML__": rich(investment.get("price", brief.get("investment", ""))),
        "__INVESTMENT_NOTE__": rich(investment.get("note", "")),
        "__CTA_BODY__": rich(brief.get("cta", {}).get("body", "")),
        "__CTA_STEPS__": cta_steps(brief.get("cta", {}).get("steps", [])),
        "__SCOPE_INCLUDED__": list_items(scope.get("included", [])),
        "__SCOPE_NOT_INCLUDED__": list_items(scope.get("not_included", [])),
        "__EXPERIENCE_INTRO__": esc(
            brief.get("experience_intro", f"Prepared for {prospect_name}, with Pathfindr experience across")
        ),
        "__LOGO_GRID__": logo_grid(manifest, brief),
        "__CASE_STUDY_SECTION__": case_study_section(case_studies),
        "__FACILITATOR_CARDS__": facilitator_cards(people),
        "__ABOUT_PATHFINDR__": about_pathfindr_section(pathfindr),
        "__CONTACT_BLOCK__": contact_block(brief.get("contact", {})),
    }

    html_out = template
    for key, value in replacements.items():
        html_out = html_out.replace(key, value)
    unreplaced = sorted(set(re.findall(r"__[A-Z0-9_]+__", html_out)))
    if unreplaced:
        raise ValueError(f"Unreplaced template tokens: {', '.join(unreplaced)}")
    return html_out


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate a standalone Pathfindr proposal microsite HTML file.")
    parser.add_argument("--brief", required=True, type=Path, help="Path to proposal brief JSON.")
    parser.add_argument("--output", required=True, type=Path, help="Output HTML path.")
    parser.add_argument("--logo-manifest", default=DEFAULT_MANIFEST, type=Path, help="Logo manifest JSON path.")
    parser.add_argument(
        "--content-library",
        default=DEFAULT_CONTENT_LIBRARY,
        type=Path,
        help="Reusable people, images, proof, and case-study content library JSON path.",
    )
    parser.add_argument("--template", default=DEFAULT_TEMPLATE, type=Path, help="HTML template path.")
    args = parser.parse_args()

    brief = read_json(args.brief)
    manifest = read_json(args.logo_manifest)
    content_library = read_json(args.content_library) if args.content_library.exists() else {}
    template = args.template.read_text(encoding="utf-8")
    html_out = render(brief, manifest, content_library, template)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(html_out, encoding="utf-8")
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
