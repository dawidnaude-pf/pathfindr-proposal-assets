#!/usr/bin/env python3
import argparse
import json
import urllib.request
from pathlib import Path


DEFAULT_MANIFEST = Path(__file__).resolve().parents[1] / "assets" / "logo-manifest.json"


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify that proposal logo URLs are public and reachable.")
    parser.add_argument("--manifest", default=DEFAULT_MANIFEST, type=Path)
    args = parser.parse_args()

    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    failures = []
    for logo in manifest.get("logos", []):
        url = logo["url"]
        if not url.startswith("https://"):
            failures.append(f"{logo['name']}: not HTTPS: {url}")
            continue
        request = urllib.request.Request(url, method="GET", headers={"User-Agent": "proposal-page-generator/1.0"})
        try:
            with urllib.request.urlopen(request, timeout=15) as response:
                status = response.status
                content_type = response.headers.get("content-type", "")
                response.read(64)
        except Exception as exc:  # noqa: BLE001 - command-line verifier should report all network failures.
            failures.append(f"{logo['name']}: {exc}")
            continue
        if status >= 400 or "image/" not in content_type:
            failures.append(f"{logo['name']}: HTTP {status}, content-type {content_type}")
        else:
            print(f"OK {logo['name']} {status} {content_type}")

    if failures:
        print("\nFAILURES")
        for failure in failures:
            print(f"- {failure}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
